package studentmanagements;
import java.sql.*;

public class StudentManager {

    public void addStudent(Student student) {

        try {

            Connection conn = DatabaseConnection.getConnection();

            String sql = "INSERT INTO students(name,email,course,age) VALUES(?,?,?,?)";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, student.getName());
            ps.setString(2, student.getEmail());
            ps.setString(3, student.getCourse());
            ps.setInt(4, student.getAge());

            ps.executeUpdate();

            System.out.println("Student added successfully!");

        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void viewStudents() {

        try {

            Connection conn = DatabaseConnection.getConnection();

            String sql = "SELECT * FROM students";

            Statement st = conn.createStatement();

            ResultSet rs = st.executeQuery(sql);

            while(rs.next()) {

                System.out.println(
                        rs.getInt("id") + " | " +
                        rs.getString("name") + " | " +
                        rs.getString("email") + " | " +
                        rs.getString("course") + " | " +
                        rs.getInt("age")
                );

            }

        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void searchStudent(int id) {

        try {

            Connection conn = DatabaseConnection.getConnection();

            String sql = "SELECT * FROM students WHERE id=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if(rs.next()) {

                System.out.println(
                        rs.getInt("id") + " | " +
                        rs.getString("name") + " | " +
                        rs.getString("email") + " | " +
                        rs.getString("course") + " | " +
                        rs.getInt("age")
                );

            } else {

                System.out.println("Student not found");

            }

        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    public void deleteStudent(int id) {

        try {

            Connection conn = DatabaseConnection.getConnection();

            String sql = "DELETE FROM students WHERE id=?";

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setInt(1, id);

            ps.executeUpdate();

            System.out.println("Student deleted successfully");

        } catch(Exception e) {
            e.printStackTrace();
        }
    }
}

